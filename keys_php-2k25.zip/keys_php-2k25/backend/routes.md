POST /users
POST /users/user/passwords

GET /users/:id
GET /users/user
GET /users/:id/passwords
GET /users/user/passwords

PUT /users/user
PUT /users/user/passwords/:passId

DELETE /users/user/passwords/:passId

POST /login
